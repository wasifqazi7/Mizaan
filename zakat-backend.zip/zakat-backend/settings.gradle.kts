rootProject.name = "zakat-backend"
